<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <title>Register Form Start</title>
    
  </head>
  <style>
    @import url('httpss://fonts.googleapis.com/css?family=Roboto');

body {
  background:linear-gradient(to right, #78a7ba 0%, #385D6C 50%, #78a7ba 99%);
}

.signup-form {
  font-family: "Roboto", sans-serif;
  width:650px;
  margin:30px auto;
  background:linear-gradient(to right, #ffffff 0%, #fafafa 50%, #ffffff 99%);
  border-radius: 10px;
}

.form-header  {
  background-color: #EFF0F1;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}

.form-header h1 {
  font-size: 30px;
  text-align:center;
  color:#666;
  padding:20px 0;
  border-bottom:1px solid #cccccc;
}
/*---------------------------------------*/
/* Form Body */
/*---------------------------------------*/
.form-body {
  padding:10px 40px;
  color:#666;
}

.form-group{
  margin-bottom:20px;
}

.form-body .label-title {
  color:#1BBA93;
  font-size: 17px;
  font-weight: bold;
}

.form-body .form-input {
    font-size: 17px;
    box-sizing: border-box;
    width: 100%;
    height: 34px;
    padding-left: 10px;
    padding-right: 10px;
    color: #333333;
    text-align: left;
    border: 1px solid #d6d6d6;
    border-radius: 4px;
    background: white;
    outline: none;
}



.horizontal-group .left{
  float:left;
  width:49%;
}

.horizontal-group .right{
  float:right;
  width:49%;
}

input[type="file"] {
 outline: none;
 cursor:pointer;
 font-size: 17px;
}

#range-label {
 width:15%;
 padding:5px;
 background-color: #1BBA93;
 color:white;
 border-radius: 5px;
 font-size: 17px;
 position: relative;
 top:-8px;
}


::-webkit-input-placeholder {
 color:#d9d9d9;
}

/*---------------------------------------*/
/* Form Footer */
/*---------------------------------------*/
.form-footer {
 clear:both;
}/*---------------------------------------*/
/* Form Footer */
/*---------------------------------------*/
.signup-form .form-footer  {
  background-color: #EFF0F1;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
  padding:10px 40px;
  text-align: right;
  border-top: 1px solid #cccccc;
}

.form-footer span {
  float:left;
  margin-top: 10px;
  color:#999;  
  font-style: italic;
  font-weight: thin;
}

.btn {
   display:inline-block;
   padding:10px 20px;
   background-color: #1BBA93;
   font-size:17px;
   border:none;
   border-radius:5px;
   color:#bcf5e7;
   cursor:pointer;
}

.btn:hover {
  background-color: #169c7b;
  color:white;
}
  </style>

  <body>
<!-- form header -->
<div class="form-header">
  <h1>Application Form</h1>
</div>

<form class="signup-form" action="register.php" method="post">
<!-- form body -->
<div class="form-body">

    <!-- Firstname and Lastname -->
    <div class="horizontal-group">
        <div class="form-group center">
            <label for="firstname" class="label-title">First name*</label>
            <input type="text" id="firstname" class="form-input" placeholder="enter your first name" required="required" name="fname"/>
        </div>
        <div class="form-group center ">
            <label for="lastname" class="label-title">Last name</label>
            <input type="text" id="lastname" class="form-input" placeholder="enter your last name" name="lname"/>
        </div>
    </div>

</div>
<div class="horizontal-group">

   
</div>
<!-- Email -->
<div class="form-body">
  <label for="email" class="label-title">Email*</label>
  <input type="email" id="email" class="form-input" placeholder="enter your email" required="required" name="email">
</div>
<div class="form-body">
  <label for="username" class="label-title">username NO*</label>
  <input type="text" id="username" class="form-input" placeholder="enter your username no." required="required" name="username">
</div>
<div class="horizontal-group" >
<div class="form-body center">
  <label for="birthday">DOB</label>
  <input type="date" name="birthday" id="birthday" required='required'>
</div>
</div>
<!-- Gender -->
<div class="horizontal-group">

    <div class="form-body center">
        <label class="label-title">Gender:</label>
        <div class="input-group">
            <label for="male">
                <input type="radio" name="gender" value="male" id="male"> Male</label>
            <label for="female">
                <input type="radio" name="gender" value="female" id="female"> Female</label>
            <label for="others">
                <input type="radio" name="gender" value="others" id="others"> others</label>    
        </div>
    </div>
    
</div> 
</div>


<!-- form footer -->
<div class="form-footer center">
  
  <button type="submit" class="btn">Submit</button>
</div>
</form>
    </form>

  </body>
</html>