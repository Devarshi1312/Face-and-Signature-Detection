<?php
$image = "s1.jpg";
$signature = "p3.jpg";

// python app.py \"test2.jpg\"
//strval("python app.py \\",$image,"\\");

function checkimg(string $image) {
    return shell_exec("python testpic.py \"$image\"");
}

function checksig(string $signature) {
    return shell_exec("python testsign.py \"$signature\"");
}

$a=checkimg($image);
$b=checksig($signature);

echo $a;
echo "<br>";
echo $b;
echo "<br>";

if ($a == 1 and $b == 1)
{
    echo "Both True";
}
elseif ($a == 1 and $b == 0)
{
    echo "Reupload signature";
    echo "<br>";
}
elseif ($a== 0 and $b == 1)
{
    echo "Reupload Image";
    echo "<br>";
}
else
{
    echo "swap and check";
    echo "<br>";
    
    $t=$image;
    $image=$signature;
    $signature=$t;

    $a=checkimg($image);
    $b=checksig($signature);

    echo $a;
    echo "<br>";
    echo $b;
    echo "<br>";

    if ($a == 1 and $b == 1)
    {
        echo "Both True After Swap";
    }
    else
    {
        echo "Reupload Both";
    }
}

?>