<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <title>Register Form Start</title>
    
  </head>
   <style>
       .topnav{
           height: 50px;
          border-radius: 10px;
           background-color: greenyellow;
           display: flex;
       }
       ul{
          padding-right: 20px;
          padding-left: 320px;
       }
       .top1{
        height: 30px;
        border-radius: 10px;
        background-color: aqua;
       }
       .top2{
        height: 30px;
          border-radius: 10px;
           background-color:aqua;
       }
       .top3{
        height: 30px;
          border-radius: 10px;
           background-color:aqua;
       }
   </style> 
  <body>
    <div class="topnav">
       <ul>
           HOME
       </ul>
       <ul>
           ABOUT US
       </ul>
       <ul>
           CONTACT US
       </ul>
    </div>
    <br>
    <div class="top1">
     <marquee behavior="" direction="left">exam dates july 2nd or 3rd week</marquee>
    </div>
    <br>
    <div class="top2">
      <marquee behavior="" direction="left">apply as fast as you can </marquee>
    </div>
<br>
    <div class="top3">
      <marquee behavior="" direction="left">applications last date-15th april 2022</marquee>
    </div>
    <div class="apply">

    </div>
    

  </body>
</html>