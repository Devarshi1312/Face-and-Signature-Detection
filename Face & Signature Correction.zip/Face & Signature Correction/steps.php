<html>
<head>
<title>Steps to Apply</title>
<style>
body{
background-image: url('pic3.jpg');
background-repeat:no-repeat;
background-size:cover;
background-position:center;
}
h1{
margin-left:150px;
margin-top:250px;
font-size:45px;
}
.signup-form .form-footer  {
  background-color: #EFF0F1;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  padding:10px 20px;
  text-align:center;
  border-top: 1px solid #cccccc;
}
hr{
width:50%;
text-align:left;
margin-left:0px;
}
ul li{
font-size:35px;
margin-left:40px;
}
.button3{
position:absolute;
top:70%;
left:34%;
}
.btn3{
text-decoration:none;
border:1px solid  transparent;
border-radius:25px;
padding: 5px 30px;
color:#fff;
background-color:#000;
}
.btn3:hover{
background-color:grey;
color:#fff;
}
</style>
</head>
<body>

<h1>Steps to Apply Online</h1>
<hr>
<ul>
<li>Apply for Online Registration</li>
<li>Fill Online Application Form</li>
<li>Upload Scanned Photo and Signature</li>
</ul>
<hr>
<div class="button3">
<div class="form-footer" >
<form action="reg.php" class="btn3"><font family="Times New Roman">
  <button type="submit" class="btn3">NEXT</button>
  </font>
  </form>  
</div>
</div>
</body>
</html>