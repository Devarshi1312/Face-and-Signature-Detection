<?php
echo "Your documents have been  successfully uploaded ";
?>
<html>
    <body>
<form action="application.php">
<button TYPE="submit"> go to home page</button>
</form>
<body>
</html>