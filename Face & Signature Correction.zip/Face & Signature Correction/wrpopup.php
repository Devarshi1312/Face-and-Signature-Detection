<?php
echo "You have uploaded wrong files ";
?>
<html>
    <body>
<form action="reg2.php">
<button TYPE="submit"> go to upload page</button>
</form>
<body>
</html>