<?php 
error_reporting(0);
?>
<?php
$servername ="localhost";
$username ="root";
$password ="";
$db="devarshi";
$conn=new mysqli($servername,$username,$password,$db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$img=$_POST['file'];
$pic=$_FILES['file'];
$username=$_POST['username'];
//print_r($pic);
$filename=$pic['name'];
$fileerror=$pic['error'];
$filetmp=$pic['tmp_name'];

$fileext=explode('.',$filename);
$filecheck=strtolower(end($fileext));

$pic1=$_FILES['file1'];
$filename1=$pic1['name'];
$fileerror1=$pic1['error'];
$filetmp1=$pic1['tmp_name'];
$fileext1=explode('.',$filename1);
$filecheck1=strtolower(end($fileext1));


$valid=array('png','jpg','jpeg','PNG','JPG','JPEG');

if((in_array($filecheck,$valid)) and (in_array($filecheck1,$valid)))
{
    $image =$filename ;
    $signature = $filename1;
    
    // python app.py \"test2.jpg\"
    //strval("python app.py \\",$image,"\\");
    
    function checkimg(string $image) {
        return shell_exec("python testpic.py \"$image\"");
    }
    
    function checksig(string $signature) {
        return shell_exec("python testsign.py \"$signature\"");
    }
    
    $a=checkimg($image);
    $b=checksig($signature);
    if ($a == 1 and $b == 1)
     {
        $sql="UPDATE  sih set sign_photo='$filename1' where username='$username'";
        $sql1="UPDATE  sih set passport_photo='$filename' where username='$username'";
        $result =$conn->query($sql);
        $result1 =$conn->query($sql1);
    }
    elseif ($a == 1 and $b == 0)
    {
    $sql1="UPDATE  sih set passport_photo='$filename' where username='$username'";
    $result1 =$conn->query($sql1);
    echo "Reupload signature";
    header('Location:reg3.php');
    }
    elseif ($a== 0 and $b == 1)
    {
    $sql="UPDATE  sih set sign_photo='$filename1' where username='$username'";
    $result =$conn->query($sql);
    echo "Reupload Image";
    header('Location:reg4.php');
    }
    else
   {
    
    $t=$image;
    $image=$signature;
    $signature=$t;

    $a=checkimg($image);
    $b=checksig($signature);

    if ($a == 1 and $b == 1)
    {
        $sql="UPDATE  sih set sign_photo='$filename' where username='$username'";
        $sql1="UPDATE  sih set passport_photo='$filename1' where username='$username'";
        $result =$conn->query($sql);
        $result1 =$conn->query($sql1);
        
    }
    else
    {
        $alert=`<script type="text/javascript">alert("YOU HAVE UPLOADED WRONG DOCUMENTS PLEASE REUPLOAD THEM ");</script>`;
           echo $alert;
        header('Location:wrpopup.php');
    }
   }
        
        
       

        

        if($result===true and $result1===true)
        {
           // header('Location:reg3.php');
          
         
           header('Location:popup.php');
           $alert='<script type="text/javascript">alert("IMAGE and SIGNATURE UPLOADED successfully\nSORRY...Something went wrong..!\nPlease Try Again...! ");</script>';
           echo $alert;
        }
        else
        {
            $alert='<script type="text/javascript">alert("IMAGE SENT FAILED\nSORRY...Something went wrong..!\nPlease Try Again...! ");</script>';
            echo $alert;
            include ("reg2.php");
        }
    

    

} 
else
{
    $alert='<script type="text/javascript">alert("WRONG FILE TYPE please upload only png,jpg,jpeg,PNG,JPG,JPEG files");</script>';
echo $alert;
include ("reg2.php");
header('Location:reg.php');
}

mysqli_close($conn);
?>