<?php
$server="localhost" ;
$username = "root";
$password="";
$db="devarshi";
$conn=mysqli_connect($server,$username,$password,$db);


if($_SERVER["REQUEST_METHOD"]=="POST")
{
   
   if(!empty($_POST['fname'])&&!empty($_POST['lname'])&&!empty($_POST['email'])&&!empty($_POST['birthday'])&&!empty($_POST['username']))
   {
      
      $fname=$_POST['fname'];
      $lname=$_POST['lname'];
      $email=$_POST['email'];
      $username=$_POST['username'];
      $birthday=date('Y-m-d',strtotime($_POST['birthday']));
      
      $query="insert into sih (fname,lname,email,username,birthday) values ('$fname','$lname','$email','$username','$birthday')";

      $run= mysqli_query($conn,$query);
   if($run)
   {
      header('Location:reg2.php');
      
   }
   else{
      echo " nit subbmitted";
      
   }
   }
  else{
      echo "all fields required";
   }
}
?>