<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <title>form 2</title>
    <style>
/*---------------------------------------*/
/* Form Body */
/*---------------------------------------*/
.form-body {
  padding:10px 40px;
  color:#666;
}

.form-group{
  margin-bottom:20px;
}

.form-body .label-title {
  color:#1BBA93;
  font-size: 17px;
  font-weight: bold;
text-align:center;
}
body {
 background: linear-gradient(to right, #78a7ba 0%, #385D6C 50%, #78a7ba 99%);
}
.upload{
width:30%;
box-shadow:0 0 3px 0 rgba(0,0,0,0.3);
background:#fff;
padding:5px;
margin:18% auto 0;
text-align:center;
height:75%;
}
button{
margin-top:35px;
margin-left:900px;
}
.btn {
   display:inline-block;
   padding:10px 20px;
   background-color: #1BBA93;
   font-size:17px;
   border:none;
   border-radius:15px;
   color:#bcf5e7;
   cursor:pointer;
}

input{
border-radius:20px;
padding:10px;
margin:10px 0;
width:50%;
border:1px solid black;
outline:none;
}
.btn:hover {
  background-color: #169c7b;
  color:white;
}
.form-body .user{
text-align:center;
}
</style>
  </head>
<body>
<div class="upload">
<form action="admitc.php" method="post" enctype="multipart/form-data">
<div class="form-body" >
    <label for="username" class="label-title">Enter Username</label><br>
    <input type="text" class="user"  name="user" placeholder="Username">
  </div>
</div>
<button type="submit" class="btn">Next</button>
</form>
</body>
</html>
