<!DOCTYPE html>
<html>
<head>
<title>Admit Card</title>
<style>
body {
 background-image: linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,00.3)) ,url('pic1.jpg');
height:100vh;
background-repeat:no-repeat;
background-size:cover;
background-position:center;
}
*{
margin:0;
padding:0;
font-family:Arial;
}
ul{
float:left;
list-style-type:none;
margin-top:15px;
}
ul li {
display:inline-block;
}
ul li a{
text-decoration:none;
color:#fff;
border:1px solid transparent;
padding:10px;
transition:0.6s ease;
}
ul li a:hover{
background-color:#fff;
color:#000;
}
ul li.active a{
background-color:#fff;
color:#000;
}
.button{
position:absolute;
top:40%;
left:24%;
}
.signup-form .form-footer  {
  background-color: #EFF0F1;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
  padding:10px 20px;
  text-align:center;
  border-top: 1px solid #cccccc;
}
.btn{
text-decoration:none;
border:1px solid  transparent;
border-radius:20px;
padding: 10px 40px;
color:#000;
background-color:deepskyblue;
}
.btn:hover{
background-color:#fff;
color:#000;
}
.button2{
position:absolute;
top:40%;
left:36%;
}
.btn2{
text-decoration:none;
border:1px solid  transparent;
border-radius:20px;
padding: auto;
color:#000;
background-color:deepskyblue;

}
.btn2:hover{
background-color:#fff;
color:#000;
}
</style>
</head>
<body>
				<ul>
				<li class="active"><a href="#"><font family="Arial"> HOME</font></a></li>
				<li><a href="contactus.html">CONTACT US</a></li >
				<li><a href="#">INSTRUCTIONS</a></li>
				<li><a href="#">FEEDBACK</a></li>
				</ul>
				</font>
<div class="button">
<div class="form-footer" >
<form action="steps.php" class="btn2"><font family="Times New Roman">
  <button type="submit" class="btn2" >APPLY NOW</button>
  </font>
  </form>  
</div>
</div>
<br>
<div class="button2">
<form action="user.php" class="btn2">
<button type="submit" class="btn2" ><font family="Times New Roman"><button type="submit" class="btn2" >GET ADMIT CARD</button></font> 
  
</form>
</div>
</body>
</html>