<?php 
error_reporting(0);
?>
<?php
$servername ="localhost";
$username ="root";
$password ="";
$db="devarshi";
$conn=new mysqli($servername,$username,$password,$db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$img=$_POST['file'];
$pic=$_FILES['file'];
$username=$_POST['username'];
//print_r($pic);
$filename=$pic['name'];
$fileerror=$pic['error'];
$filetmp=$pic['tmp_name'];

$fileext=explode('.',$filename);
$filecheck=strtolower(end($fileext));




$valid=array('png','jpg','jpeg','PNG','JPG','JPEG');

if(in_array($filecheck,$valid))
{
   
    $signature = $filename;
    
    // python app.py \"test2.jpg\"
    //strval("python app.py \\",$image,"\\");
    
   
    
    function checksig(string $signature) {
        return shell_exec("python testsign.py \"$signature\"");
    }
    
    
    $b=checksig($signature);
    if ( $b == 1)
     {
        $sql="UPDATE  sih set sign_photo='$filename' where username='$username'";
       
        $result =$conn->query($sql);
        if($result===true)
        {
           // header('Location:reg3.php');
           $alert='<script type="text/javascript">alert("IMAGE SENT successfully\nSORRY...Something went wrong..!\nPlease Try Again...! ");</script>';
           echo $alert;
           header('Location:popup.php');
        }
        else
        {
            $alert='<script type="text/javascript">alert("IMAGE SENT FAILED\nSORRY...Something went wrong..!\nPlease Try Again...! ");</script>';
            echo $alert;
            header('Location:reg3.php');
        }
        
     }
    
    else
     {
        $alert='<script type="text/javascript">alert("YOU HAVE UPLOADED WRONG DOCUMENTS PLEASE REUPLOAD THEM ");</script>';
           echo $alert;
        header('Location:reg3.php');
    }
   }
        
        
       

        

       
    

    

else
{
    $alert='<script type="text/javascript">alert("WRONG FILE TYPE please upload only png,jpg,jpeg,PNG,JPG,JPEG files");</script>';
echo $alert;

header('Location:reg3.php');
}

mysqli_close($conn);
?>