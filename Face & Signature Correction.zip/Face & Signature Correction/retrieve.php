
                                <?php 
                                    $conn = mysqli_connect("localhost","root","","devarshi");

                                        $query = "SELECT * FROM sih3";
                                        $query_run = mysqli_query($conn,$query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $row)
                                            {
                                             ?>
                                             <img src="<?php echo $row['sign_photo'];?>" height="420" width="620" >

                                        <?php
                                         }
                                         }
                                        ?>